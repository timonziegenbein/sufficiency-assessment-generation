Insufficiently Supported Arguments in Argumentative Essays
----------------------------------------------------------

The corpus contains 1029 arguments. The folder contains the following files:

1. data-tokenized.tsv: the 1029 arguments and their annotations. Each argument is 
   tokenized using the language tool segmenter.

2. data-splitting.tsv: the data splitting for each of the 100 folds of the repeated CV. 
   Each column represents a single run and the assignment of each essay in train, test and    
   development set.

3. guideline.pdf: the annotation guideline.
  
   	   
   	   
Citation
--------
   	   
If you use the data, please cite the following publication

   Stab and Iryna Gurevych. 2017. Recognizing Insufficiently Supported Arguments in 
   Argumentative Essays. In: Proceedings of the 15th Conference of the European Chapter of 
   the Association for Computational Linguistics (EACL 2017), p. (to appear)